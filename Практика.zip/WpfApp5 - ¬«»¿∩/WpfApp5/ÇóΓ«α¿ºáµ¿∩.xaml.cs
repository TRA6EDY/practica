﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp5
{
	/// <summary>
	/// Логика взаимодействия для Авторизация.xaml
	/// </summary>
	public partial class Авторизация : Window
	{
		public Авторизация()
		{
			InitializeComponent();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			using (var db = new Практика_ШесковEntities())
			{
				var Pol = db.Посетитель.FirstOrDefault(Посетитель => Посетитель.логин == Логин.Text & Посетитель.пароль == Пароль.Text);
				if (Pol == null)
				{
					MessageBox.Show("Такого, увы, нет!", "Неудачный вход");
				}
				else
				{
					string name = Pol.Фамилия + " " + Pol.Имя + " " + Pol.Отчество;
					MessageBox.Show("Вы вошли под именем" + " " + name, "Успешный вход");
					MainWindow a = new MainWindow();
					a.Show();
					this.Close();
				}
			}

		}

		private void Вход2_Click(object sender, RoutedEventArgs e)
		{
			using (var db = new Практика_ШесковEntities())
			{
				var Pol = db.Сотрудник.FirstOrDefault(Сотрудник => Сотрудник.Логин == Логин.Text & Сотрудник.Пароль == Пароль.Text);
				if (Pol == null)
				{
					MessageBox.Show("Такого, увы, нет!", "Неудачный вход");
				}
				else
				{
					string name = Pol.Фамилия + " " + Pol.Имя + " " + Pol.Отчество;
					MessageBox.Show("Вы вошли под именем" + " " + name, "Успешный вход");
					Запись_на_групповое_мероприятие a = new Запись_на_групповое_мероприятие();
					a.Show();
					this.Close();
				}
			}
		}

		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			Регистрация регистрация = new Регистрация();
			регистрация.Show();
			this.Close();
		}
	}
}
