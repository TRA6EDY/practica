﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp5
{
    /// <summary>
    /// Логика взаимодействия для Регистрация.xaml
    /// </summary>
    public partial class Регистрация : Window
    {
        public Регистрация()
        {
            InitializeComponent();
        }

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			using (var db = new Практика_ШесковEntities())
			{
				Посетитель посетитель = new Посетитель();
				посетитель.логин = Логин.Text;
				посетитель.пароль = Пароль.Text;
				посетитель.Имя = Имя.Text;
				посетитель.Фамилия = Фамилия.Text;
				посетитель.Отчество = Отчество.Text;
				db.Посетитель.Add(посетитель);
				db.SaveChanges();
				MessageBox.Show("Успешно!","Регистрация,");
				Авторизация авторизация = new Авторизация();
				авторизация.Show();
			
			}
		}
	}
}
