﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp5
{
    /// <summary>
    /// Логика взаимодействия для Список_посетителей.xaml
    /// </summary>
    public partial class Список_посетителей : Window
    {
        public Список_посетителей()
        {
            InitializeComponent();
			using (var db = new Практика_ШесковEntities())
			{
				var users = db.Сотрудник.ToList();
				datag.ItemsSource = users;
			}
        }

		private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			
					
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			Информация_посетителей информация_Посетителей = new Информация_посетителей();
			информация_Посетителей.Show();
			this.Close();
		}
	}
}
