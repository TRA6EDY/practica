﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp5
{
	/// <summary>
	/// Логика взаимодействия для Запись_на_групповое_мероприятие.xaml
	/// </summary>
	public partial class Запись_на_групповое_мероприятие : Window
	{
		public Запись_на_групповое_мероприятие()
		{
			InitializeComponent();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			MainWindow mainWindow = new MainWindow();
			mainWindow.Show();
			this.Hide();
		}

		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			Информация_посетителей информация_Посетителей = new Информация_посетителей();
			информация_Посетителей.Show();

			this.Hide();
		}

		private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
		{

		}

		private void Загрузить_фото_Click(object sender, RoutedEventArgs e)
		{
			Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
			dlg.FileName = "Photo";
			dlg.DefaultExt = "jpg";
			dlg.Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif";

			Nullable<bool> result = dlg.ShowDialog();
			if (result == true)
			{
				Name_file.Text = dlg.FileName;
				BitmapImage bitmap = new BitmapImage();
				bitmap.BeginInit();
				bitmap.UriSource = new Uri(dlg.FileName);
				bitmap.EndInit();
				Фото.Source = bitmap;
				Фото.Visibility = Visibility.Visible;
			}
		}
	}
}