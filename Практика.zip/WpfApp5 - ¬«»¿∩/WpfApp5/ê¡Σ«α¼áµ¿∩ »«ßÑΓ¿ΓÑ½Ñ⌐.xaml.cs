﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
namespace WpfApp5
{
	/// <summary>
	/// Логика взаимодействия для Информация_посетителей.xaml
	/// </summary>
	public partial class Информация_посетителей : Window
	{
		public Информация_посетителей()
		{
			InitializeComponent();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			Запись_на_групповое_мероприятие запись_На_Групповое_Мероприятие = new Запись_на_групповое_мероприятие();
			запись_На_Групповое_Мероприятие.Show();
			this.Hide();
		}

		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			Список_посетителей список_Посетителей = new Список_посетителей();
			список_Посетителей.Show();
			this.Hide();
		}

		private void Button_Click_2(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("Заявка на рассмотрении БОССОМ", "Успешно!");
		}
	}
}
